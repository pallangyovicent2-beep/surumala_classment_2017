# V19 Release Notes

V19 focuses on quality assurance and security hardening rather than adding a large new feature set.

### Key checks
- Contribution amount remains TSH 5,000/month.
- M-Pesa remains the payment method.
- No loans are included.
- Approval flow remains PENDING → APPROVED/REJECTED.
- Admin-only controls remain protected by role/RLS design.
- Payment confirmation is server-trusted.
- Audit logging remains part of the architecture.

### Important
This ZIP is a source project, not a signed production APK/IPA. A Flutter build environment and the real Supabase/M-Pesa configuration are still required for final release testing.

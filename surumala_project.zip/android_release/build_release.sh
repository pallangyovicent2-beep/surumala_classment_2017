#!/usr/bin/env bash
set -euo pipefail
flutter pub get
flutter build appbundle --release \
  --dart-define=SUPABASE_URL="${SUPABASE_URL:?Set SUPABASE_URL}" \
  --dart-define=SUPABASE_ANON_KEY="${SUPABASE_ANON_KEY:?Set SUPABASE_ANON_KEY}"
echo "AAB: build/app/outputs/bundle/release/app-release.aab"

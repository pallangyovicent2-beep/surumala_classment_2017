# Google Play preparation

App name: SURUMALA CLASSMENT 2017
Category: Social / community group (choose the closest available Play Console category)

Required before submission:
1. Google Play Console developer account.
2. Signed Android App Bundle (.aab).
3. App icon and screenshots (can be added later).
4. Privacy policy URL appropriate to the final data practices.
5. Data Safety form completed accurately.
6. Content rating completed.
7. Testing track/release configured according to current Google Play requirements.

No logo is included yet; the app can use the current built-in group icon until a final logo is supplied.

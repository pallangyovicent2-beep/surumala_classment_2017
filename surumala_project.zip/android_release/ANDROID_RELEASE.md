# SURUMALA CLASSMENT 2017 — Android Release Package

Package name target: `com.surumala.classment2017`
Version: `1.0.0+21`

## What is included
- Flutter application source from the production-preparation baseline
- Supabase schema and security policies
- M-Pesa server-side integration boundary
- Android release configuration notes
- Production/QA checklists

## Important
This is the Android **release-source package**, not a compiled `.aab` file. A real Google Play upload requires a Flutter/Android build environment and release signing credentials.

## Build command
From the project root on a machine/cloud Flutter environment:

`flutter pub get`

`flutter build appbundle --release --dart-define=SUPABASE_URL=YOUR_PUBLIC_SUPABASE_URL --dart-define=SUPABASE_ANON_KEY=YOUR_PUBLIC_SUPABASE_ANON_KEY`

The resulting file is normally under `build/app/outputs/bundle/release/`.

## Signing
Do not put a keystore, keystore password, or private signing key into this ZIP or into chat. Configure a private Android release keystore in the build environment before uploading to Google Play.

## Before publishing
- Confirm the Supabase project and production schema/RLS are deployed.
- Confirm the public Supabase URL and anon/public key are configured at build time.
- Complete the real Tanzania M-Pesa provider integration and server secrets before enabling live payments.
- Test registration, PENDING approval, APPROVED login, contribution history, and admin permissions.

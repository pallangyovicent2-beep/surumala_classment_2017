# SURUMALA CLASSMENT 2017 — Cloud Build

This package is prepared for a Flutter cloud build. The source package did not contain the generated `android/` platform folder, so `codemagic.yaml` generates it automatically on the build machine before compiling.

## Target
- App: SURUMALA CLASSMENT 2017
- Android package: `com.surumala.classment2017`
- Version: `1.0.0+21`
- Output: Android App Bundle (`.aab`)

## Recommended service
Codemagic can build Flutter Android App Bundles in the cloud. Connect this project to a Git repository, then start the `surumala-android-release` workflow.

## Required before a Play Store release
1. Configure Android code signing in Codemagic with a release/upload keystore.
2. Keep a private backup of that keystore and its passwords.
3. If the app will use real Supabase, add the public `SUPABASE_URL` and `SUPABASE_ANON_KEY` as build environment variables. Never put a Supabase service-role key in the Flutter app.
4. Build the signed `.aab`.

## Important
The first cloud build should be treated as a compilation test. A signed AAB is the artifact needed for Google Play; the app is not automatically published to Play Store merely by creating the AAB.

# SURUMALA CLASSMENT 2017 — V20 FINAL RELEASE

## Kilichofungwa kwenye V20
- Authentication + member approval flow
- Member directory + profiles
- Monthly contribution: TSH 5,000
- M-Pesa server-side integration foundation
- Contribution history + payment states
- Admin dashboard + financial summary
- Announcements + meetings + attendance
- Notifications foundation
- Security + audit logs
- Settings + password change
- Supabase RLS foundation
- Version `1.0.0+20`

## Release gate
V20 ni **release candidate**, si uthibitisho wa deployment ya production. Kabla ya kutoa app kwa wanachama, lazima:

1. Supabase project iundwe na migrations zote zi-run kwa mpangilio.
2. Admin wa kwanza apandishwe kwa utaratibu salama wa `setup_admin.sql`.
3. Flutter SDK environment ifanye:
   - `flutter pub get`
   - `flutter analyze`
   - `flutter test`
   - Android release build
   - iOS release build
   - Web release build
4. RLS tests zihakikishe mwanachama hawezi kuona/kuhariri data ya mtu mwingine.
5. M-Pesa credentials ziwekwe server-side tu na callback/webhook ijaribiwe.
6. Payment iwe `PAID` baada ya uthibitisho wa provider, si kwa client.
7. Backup, monitoring na recovery procedure viwekwe.

## Acceptance checklist
- [ ] Register → PENDING
- [ ] Admin → APPROVED
- [ ] Approved member → Login
- [ ] Member sees own contribution history
- [ ] TSH 5,000 enforced by database
- [ ] M-Pesa callback updates payment securely
- [ ] Admin sees financial totals
- [ ] Member directory only exposes approved members
- [ ] Attendance works
- [ ] Announcements work
- [ ] Notifications work
- [ ] Audit log restricted to Admin
- [ ] Logout works
- [ ] Password change works
- [ ] Android tested
- [ ] iPhone tested
- [ ] Web tested

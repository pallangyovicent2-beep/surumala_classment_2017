from pathlib import Path
import re, sys
root=Path(__file__).resolve().parent
text='\n'.join(p.read_text(errors='ignore') for p in root.rglob('*') if p.is_file() and p.suffix in {'.dart','.sql','.ts','.md','.yaml'})
checks=[
    ('TSH 5,000 constraint', 'amount=5000' in text or 'amount = 5000' in text),
    ('M-Pesa present', 'MPESA' in text),
    ('No loan module wording', 'Hakuna module ya mikopo' in text or 'hakuna mikopo' in text.lower()),
    ('Service role is server-side only', 'SUPABASE_SERVICE_ROLE_KEY' in (root/'supabase/functions/mpesa-stk/index.ts').read_text(errors='ignore')),
    ('Flutter client does not define service role key', 'SUPABASE_SERVICE_ROLE_KEY' not in (root/'lib/services/backend_config.dart').read_text(errors='ignore')),
    ('Supabase anon config exists', 'SUPABASE_ANON_KEY' in (root/'lib/services/backend_config.dart').read_text(errors='ignore')),
]
failed=[]
for name, ok in checks:
    print(('PASS' if ok else 'FAIL')+' - '+name)
    if not ok: failed.append(name)
if failed:
    sys.exit(1)
print('All V19 static checks passed.')

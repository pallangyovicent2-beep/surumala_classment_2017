import 'supabase_service.dart';

class AuditService {
  static Future<List<Map<String, dynamic>>> latest({int limit = 50}) async {
    final rows = await SupabaseService.client
        .from('audit_logs')
        .select('id,actor_id,action,entity_type,entity_id,details,created_at')
        .order('created_at', ascending: false)
        .limit(limit);
    return List<Map<String, dynamic>>.from(rows);
  }
}

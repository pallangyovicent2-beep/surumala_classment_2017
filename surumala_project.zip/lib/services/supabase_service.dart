import 'package:supabase_flutter/supabase_flutter.dart';
import 'backend_config.dart';

class SupabaseService {
  static SupabaseClient get client => Supabase.instance.client;
  static Future<void> initialize() async {
    if (!BackendConfig.configured) return;
    await Supabase.initialize(url: BackendConfig.supabaseUrl, anonKey: BackendConfig.supabaseAnonKey);
  }
  static bool get configured => BackendConfig.configured;
}

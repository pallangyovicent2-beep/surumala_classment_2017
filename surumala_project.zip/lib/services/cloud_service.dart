import 'backend_config.dart';

/// Cloud integration boundary. The UI can use this service now; once the
/// Supabase project is configured, replace the TODO implementations with
/// Supabase auth/database calls. Keeping secrets out of the Flutter client is
/// intentional.
class CloudService {
  static bool get configured => BackendConfig.enabled;

  static Future<void> initialize() async {
    if (!configured) return;
    // TODO: initialize Supabase with BackendConfig.url and anonKey.
  }

  static Future<bool> login(String phone, String password) async {
    if (!configured) return false;
    // TODO: authenticate using the phone/email identity strategy selected.
    return false;
  }
}

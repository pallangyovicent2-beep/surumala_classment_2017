import 'package:supabase_flutter/supabase_flutter.dart';
import 'supabase_service.dart';

String normalizeTzPhone(String value) {
  final s = value.trim().replaceAll(' ', '');
  if (s.startsWith('+255')) return s;
  if (s.startsWith('255')) return '+$s';
  if (s.startsWith('0') && s.length == 10) return '+255${s.substring(1)}';
  return s;
}

class AuthService {
  static Future<AuthResponse> register({required String phone, required String password, required String fullName, required String location}) =>
      SupabaseService.client.auth.signUp(phone: normalizeTzPhone(phone), password: password, data: {'full_name': fullName.trim(), 'location': location.trim()});
  static Future<AuthResponse> login({required String phone, required String password}) =>
      SupabaseService.client.auth.signInWithPassword(phone: normalizeTzPhone(phone), password: password);
  static Future<void> logout() => SupabaseService.client.auth.signOut();
}

import 'package:supabase_flutter/supabase_flutter.dart';
import 'supabase_service.dart';

class PaymentService {
  static Future<Map<String, dynamic>> startMpesa({required String contributionId, required String phone}) async {
    final res = await SupabaseService.client.functions.invoke(
      'mpesa-stk',
      body: {'contribution_id': contributionId, 'phone': phone},
    );
    if (res.data is Map<String, dynamic>) return Map<String, dynamic>.from(res.data as Map);
    throw const PostgrestException(message: 'Majibu ya malipo hayakueleweka.');
  }
}

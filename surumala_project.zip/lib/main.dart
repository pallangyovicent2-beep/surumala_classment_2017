// SURUMALA CLASSMENT 2017 V19 - QA / hardening baseline
import 'package:flutter/material.dart';
import 'services/auth_service.dart';
import 'services/supabase_service.dart';
import 'services/payment_service.dart';
import 'services/audit_service.dart';

const blue = Color(0xFF0757A6), green = Color(0xFF16A34A), gold = Color(0xFFF2B01E), navy = Color(0xFF063B70);

Future<void> main() async { WidgetsFlutterBinding.ensureInitialized(); await SupabaseService.initialize(); runApp(const App()); }

class App extends StatelessWidget { const App({super.key}); @override Widget build(BuildContext c) => MaterialApp(debugShowCheckedModeBanner:false,title:'SURUMALA CLASSMENT 2017',theme:ThemeData(useMaterial3:true,colorScheme:ColorScheme.fromSeed(seedColor:blue)),home:const LoginPage()); }

class Brand extends StatelessWidget { const Brand({super.key}); @override Widget build(BuildContext c)=>Column(children:const[CircleAvatar(radius:40,backgroundColor:blue,child:Icon(Icons.groups,size:45,color:Colors.white)),SizedBox(height:8),Text('SURUMALA',style:TextStyle(fontSize:28,fontWeight:FontWeight.w900,color:blue)),Text('CLASSMENT 2017',style:TextStyle(fontSize:18,fontWeight:FontWeight.w800,color:green)),Text('PAMOJA TUNAJENGA MAISHA BORA',style:TextStyle(fontSize:11,fontWeight:FontWeight.w700,color:navy))]); }

String err(Object e)=>e.toString().replaceFirst('AuthException(message: ','').split(', statusCode').first.replaceAll(')', '');

class LoginPage extends StatefulWidget { const LoginPage({super.key}); @override State<LoginPage> createState()=>_LoginState(); }
class _LoginState extends State<LoginPage>{final phone=TextEditingController(),pass=TextEditingController();bool busy=false;Future<void> go()async{if(!SupabaseService.configured){msg('Supabase haijawekwa. Tumia README kusanidi.');return;}setState(()=>busy=true);try{await AuthService.login(phone:phone.text,password:pass.text);if(!mounted)return;final u=SupabaseService.client.auth.currentUser;final row=await SupabaseService.client.from('members').select().eq('auth_user_id',u!.id).maybeSingle();if(!mounted)return;if(row==null){msg('Akaunti imeingia lakini profile haijapatikana.');await AuthService.logout();}else if(row['status']!='APPROVED'){await AuthService.logout();Navigator.push(context,MaterialPageRoute(builder:(_)=>PendingPage(status:row['status'])));}else{Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>Dashboard(row:row)));}}catch(e){msg(err(e));}finally{if(mounted)setState(()=>busy=false);}}
void msg(String s)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s)));@override Widget build(BuildContext c)=>Scaffold(body:SafeArea(child:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:440),child:Column(children:[const Brand(),const SizedBox(height:28),TextField(controller:phone,keyboardType:TextInputType.phone,decoration:const InputDecoration(labelText:'Namba ya simu',prefixIcon:Icon(Icons.phone),border:OutlineInputBorder())),const SizedBox(height:12),TextField(controller:pass,obscureText:true,decoration:const InputDecoration(labelText:'Password',prefixIcon:Icon(Icons.lock),border:OutlineInputBorder())),const SizedBox(height:18),SizedBox(width:double.infinity,height:52,child:FilledButton(onPressed:busy?null:go,child:Text(busy?'INASUBIRI...':'INGIA'))),TextButton(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const RegisterPage())),child:const Text('JISAJILI KAMA MWANACHAMA')),Text('Cloud: ${SupabaseService.configured?'IMEUNGANISHWA':'HAIJAWEKWA'}',style:TextStyle(color:SupabaseService.configured?green:gold,fontWeight:FontWeight.bold))]))))));}

class RegisterPage extends StatefulWidget{const RegisterPage({super.key});@override State<RegisterPage> createState()=>_RegisterState();}
class _RegisterState extends State<RegisterPage> {
  final name = TextEditingController();
  final phone = TextEditingController();
  final pass = TextEditingController();
  final location = TextEditingController();
  bool busy = false;

  Future<void> reg() async {
    if (name.text.trim().isEmpty || phone.text.trim().isEmpty || pass.text.length < 6) {
      msg('Jaza jina, simu na password yenye angalau herufi 6.');
      return;
    }
    if (!SupabaseService.configured) {
      msg('Supabase haijawekwa.');
      return;
    }
    setState(() => busy = true);
    try {
      final r = await AuthService.register(
        phone: phone.text,
        password: pass.text,
        fullName: name.text,
        location: location.text,
      );
      if (!mounted) return;
      await AuthService.logout();
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const PendingPage(status: 'PENDING')),
      );
      if (r.user == null) msg('Usajili haukukamilika.');
    } catch (e) {
      msg(err(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  void msg(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: const Text('USAJILI WA MWANACHAMA')),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              const Brand(),
              const SizedBox(height: 20),
              TextField(
                controller: name,
                decoration: const InputDecoration(labelText: 'Jina kamili', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: phone,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(labelText: 'Namba ya simu', hintText: '07XXXXXXXX', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: location,
                decoration: const InputDecoration(labelText: 'Eneo unaloishi (hiari)', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: pass,
                obscureText: true,
                decoration: const InputDecoration(labelText: 'Password', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: FilledButton(
                  onPressed: busy ? null : reg,
                  child: Text(busy ? 'INASUBIRI...' : 'TUMA USAJILI'),
                ),
              ),
            ],
          ),
        ),
      );
}

class PendingPage extends StatelessWidget{final String status;const PendingPage({super.key,required this.status});@override Widget build(BuildContext c)=>Scaffold(body:Center(child:Padding(padding:const EdgeInsets.all(28),child:Column(mainAxisSize:MainAxisSize.min,children:[Icon(status=='REJECTED'?Icons.cancel_outlined:Icons.hourglass_top,color:status=='REJECTED'?Colors.red:gold,size:80),const SizedBox(height:15),Text(status=='REJECTED'?'USAJILI UMEKATALIWA':'USAJILI UPO KWENYE UCHUNGUZI',textAlign:TextAlign.center,style:const TextStyle(fontSize:22,fontWeight:FontWeight.w900)),const SizedBox(height:10),Text(status=='REJECTED'?'Wasiliana na Admin kwa maelekezo.':'Admin lazima aidhinishe akaunti yako kabla ya kuingia.',textAlign:TextAlign.center),const SizedBox(height:20),FilledButton(onPressed:()=>Navigator.popUntil(c,(r)=>r.isFirst),child:const Text('RUDI LOGIN'))]))));}

class Dashboard extends StatefulWidget { final Map<String,dynamic> row; const Dashboard({super.key,required this.row}); @override State<Dashboard> createState()=>_DashboardState(); }
class _DashboardState extends State<Dashboard>{
  int tab=0;
  Future<void> logout()async{await AuthService.logout();if(mounted)Navigator.pushAndRemoveUntil(context,MaterialPageRoute(builder:(_)=>const LoginPage()),(_)=>false);}
  @override Widget build(BuildContext c){
    final isAdmin=(widget.row['role']??'MEMBER')=='ADMIN';
    final pages=<Widget>[
      HomePage(row:widget.row,onContributions:()=>setState(()=>tab=1)),
      ContributionsPage(member:widget.row),
      MembersPage(),
      MeetingsPage(),
      AnnouncementsPage(),
      AttendancePage(member:widget.row),
      ProfilePage(row:widget.row,onLogout:logout),
      if(isAdmin) const AdminPage(),
      SettingsPage(row:widget.row,isAdmin:isAdmin),
    ];
    final destinations=<NavigationDestination>[
      const NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Nyumbani'),
      const NavigationDestination(icon:Icon(Icons.payments_outlined),selectedIcon:Icon(Icons.payments),label:'Michango'),
      const NavigationDestination(icon:Icon(Icons.groups_outlined),selectedIcon:Icon(Icons.groups),label:'Wanachama'),
      const NavigationDestination(icon:Icon(Icons.event_outlined),selectedIcon:Icon(Icons.event),label:'Mikutano'),
      const NavigationDestination(icon:Icon(Icons.campaign_outlined),selectedIcon:Icon(Icons.campaign),label:'Matangazo'),
      const NavigationDestination(icon:Icon(Icons.fact_check_outlined),selectedIcon:Icon(Icons.fact_check),label:'Mahudhurio'),
      const NavigationDestination(icon:Icon(Icons.person_outline),selectedIcon:Icon(Icons.person),label:'Wasifu'),
      if(isAdmin) const NavigationDestination(icon:Icon(Icons.admin_panel_settings_outlined),selectedIcon:Icon(Icons.admin_panel_settings),label:'Admin'),
      const NavigationDestination(icon:Icon(Icons.settings_outlined),selectedIcon:Icon(Icons.settings),label:'Mipangilio'),
    ];
    return Scaffold(
      appBar:AppBar(title:const Text('SURUMALA CLASSMENT 2017'),actions:[IconButton(tooltip:'Mipangilio',onPressed:()=>setState(()=>tab=pages.length-1),icon:const Icon(Icons.settings)),IconButton(onPressed:logout,icon:const Icon(Icons.logout))]),
      body:pages[tab],
      bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),destinations:destinations),
    );
  }
}

class HomePage extends StatelessWidget{final Map<String,dynamic> row;final VoidCallback onContributions;const HomePage({super.key,required this.row,required this.onContributions});@override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(color:blue,borderRadius:BorderRadius.circular(20)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('KARIBU, ${row['full_name']}',style:const TextStyle(color:Colors.white,fontSize:21,fontWeight:FontWeight.w900)),const SizedBox(height:5),Text('${row['member_no']} • ${row['role']}',style:const TextStyle(color:Colors.white70))]),),const SizedBox(height:14),Card(child:ListTile(leading:const Icon(Icons.payments,color:green),title:const Text('MCHANGO WA MWEZI'),subtitle:const Text('TSH 5,000'),trailing:FilledButton(onPressed:onContributions,child:const Text('LIPA')))),Card(child:ListTile(leading:const Icon(Icons.groups,color:blue),title:const Text('WANACHAMA'),subtitle:const Text('Orodha ya wanachama walioidhinishwa'))),Card(child:ListTile(leading:const Icon(Icons.calendar_month,color:gold),title:const Text('MIKUTANO'),subtitle:const Text('Ratiba za mikutano ya chama'))),Card(child:ListTile(leading:const Icon(Icons.campaign,color:navy),title:const Text('MATANGAZO'),subtitle:const Text('Taarifa muhimu za chama'))),const Card(child:Padding(padding:EdgeInsets.all(18),child:Text('Hakuna module ya mikopo. Michango yote ni TSH 5,000 kwa mwezi.')))]);}

class ContributionsPage extends StatefulWidget {
  final Map<String, dynamic> member;
  const ContributionsPage({super.key, required this.member});
  @override
  State<ContributionsPage> createState() => _ContributionsState();
}

class _ContributionsState extends State<ContributionsPage> {
  List<Map<String, dynamic>> items = [];
  bool loading = true;
  String? error;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final m = await SupabaseService.client
          .from('members')
          .select('id')
          .eq('auth_user_id', SupabaseService.client.auth.currentUser!.id)
          .single();
      final r = await SupabaseService.client
          .from('contributions')
          .select()
          .eq('member_id', m['id'])
          .order('contribution_month', ascending: false);
      if (mounted) setState(() => items = List<Map<String, dynamic>>.from(r));
    } catch (e) {
      if (mounted) setState(() => error = err(e));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> requestPayment() async {
    final phoneCtl = TextEditingController();
    try {
      final m = await SupabaseService.client
          .from('members')
          .select('id,phone')
          .eq('auth_user_id', SupabaseService.client.auth.currentUser!.id)
          .single();
      phoneCtl.text = (m['phone'] ?? '').toString();
      final phone = await showDialog<String>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('M-Pesa'),
          content: TextField(
            controller: phoneCtl,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(
              labelText: 'Namba ya M-Pesa',
              hintText: '07XXXXXXXX',
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Ghairi'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, phoneCtl.text.trim()),
              child: const Text('Endelea'),
            ),
          ],
        ),
      );
      if (phone == null || phone.isEmpty) return;
      final now = DateTime.now();
      final month = DateTime(now.year, now.month, 1)
          .toIso8601String()
          .substring(0, 10);
      final c = await SupabaseService.client
          .from('contributions')
          .upsert(
            {
              'member_id': m['id'],
              'amount': 5000,
              'contribution_month': month,
              'payment_method': 'MPESA',
              'status': 'PENDING',
            },
            onConflict: 'member_id,contribution_month',
          )
          .select()
          .single();
      final result = await PaymentService.startMpesa(
        contributionId: c['id'].toString(),
        phone: phone,
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(result['error'] ?? 'Ombi la M-Pesa limeanzishwa.')),
        );
        load();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err(e))));
      }
    } finally {
      phoneCtl.dispose();
    }
  }

  @override
  Widget build(BuildContext c) => RefreshIndicator(
        onRefresh: load,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('MCHANGO WA MWEZI', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 5),
                    const Text('TSH 5,000', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: green)),
                    const SizedBox(height: 8),
                    const Text('Njia: M-Pesa'),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        onPressed: requestPayment,
                        icon: const Icon(Icons.phone_android),
                        label: const Text('ANZA MALIPO'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            const Text('HISTORIA YA MICHANGO', style: TextStyle(fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            if (loading) const Center(child: CircularProgressIndicator()),
            if (error != null) Text(error!),
            if (!loading && items.isEmpty)
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(18),
                  child: Text('Bado hakuna rekodi za michango.'),
                ),
              ),
            ...items.map(
              (x) => Card(
                child: ListTile(
                  leading: Icon(
                    x['status'] == 'PAID' ? Icons.check_circle : Icons.hourglass_top,
                    color: x['status'] == 'PAID' ? green : gold,
                  ),
                  title: Text('TSH ${x['amount']}'),
                  subtitle: Text('${x['contribution_month']} • ${x['payment_method']}'),
                  trailing: Text('${x['status']}'),
                ),
              ),
            ),
          ],
        ),
      );
}
class MembersPage extends StatefulWidget{const MembersPage({super.key});@override State<MembersPage> createState()=>_MembersState();}
class _MembersState extends State<MembersPage>{List<Map<String,dynamic>> rows=[];bool loading=true;@override void initState(){super.initState();load();}Future<void> load()async{try{final r=await SupabaseService.client.from('members').select('member_no,full_name,role,status').eq('status','APPROVED').order('full_name');if(mounted)setState(()=>rows=List<Map<String,dynamic>>.from(r));}finally{if(mounted)setState(()=>loading=false);}}@override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[const Text('WANACHAMA WALIOIDHINISHWA',style:TextStyle(fontSize:18,fontWeight:FontWeight.w900)),const SizedBox(height:10),if(loading)const Center(child:CircularProgressIndicator()),...rows.map((m)=>Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.person)),title:Text(m['full_name']??''),subtitle:Text('${m['member_no']} • ${m['role']}'))))]);}

class MeetingsPage extends StatefulWidget{const MeetingsPage({super.key});@override State<MeetingsPage> createState()=>_MeetingsState();}
class _MeetingsState extends State<MeetingsPage>{List<Map<String,dynamic>> rows=[];bool loading=true;@override void initState(){super.initState();load();}Future<void> load()async{try{final r=await SupabaseService.client.from('meetings').select().order('meeting_date');if(mounted)setState(()=>rows=List<Map<String,dynamic>>.from(r));}finally{if(mounted)setState(()=>loading=false);}}@override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[const Text('MIKUTANO',style:TextStyle(fontSize:18,fontWeight:FontWeight.w900)),const SizedBox(height:10),if(loading)const Center(child:CircularProgressIndicator()),if(!loading&&rows.isEmpty)const Card(child:Padding(padding:EdgeInsets.all(18),child:Text('Hakuna mkutano uliowekwa bado.'))),...rows.map((m)=>Card(child:ListTile(leading:const Icon(Icons.event,color:gold),title:Text(m['title']??''),subtitle:Text('${m['meeting_date']}\n${m['venue']??''}'))))]);}


class AnnouncementsPage extends StatefulWidget{const AnnouncementsPage({super.key});@override State<AnnouncementsPage> createState()=>_AnnouncementsState();}
class _AnnouncementsState extends State<AnnouncementsPage>{List<Map<String,dynamic>> rows=[];bool loading=true;@override void initState(){super.initState();load();}Future<void> load()async{try{final r=await SupabaseService.client.from('announcements').select().order('created_at',ascending:false);if(mounted)setState(()=>rows=List<Map<String,dynamic>>.from(r));}catch(e){}finally{if(mounted)setState(()=>loading=false);}}@override Widget build(BuildContext c)=>RefreshIndicator(onRefresh:load,child:ListView(padding:const EdgeInsets.all(16),children:[const Text('MATANGAZO',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),const SizedBox(height:10),if(loading)const Center(child:CircularProgressIndicator()),if(!loading&&rows.isEmpty)const Card(child:Padding(padding:EdgeInsets.all(18),child:Text('Hakuna tangazo jipya.'))),...rows.map((a)=>Card(child:ListTile(leading:const Icon(Icons.campaign,color:navy),title:Text(a['title']??''),subtitle:Text(a['body']??''))))]));}

class AttendancePage extends StatefulWidget{final Map<String,dynamic> member;const AttendancePage({super.key,required this.member});@override State<AttendancePage> createState()=>_AttendanceState();}
class _AttendanceState extends State<AttendancePage>{List<Map<String,dynamic>> meetings=[];bool loading=true;@override void initState(){super.initState();load();}Future<void> load()async{try{final r=await SupabaseService.client.from('meetings').select().order('meeting_date',ascending:false);if(mounted)setState(()=>meetings=List<Map<String,dynamic>>.from(r));}catch(e){}finally{if(mounted)setState(()=>loading=false);}}Future<void> mark(Map<String,dynamic> meeting,bool present)async{try{final m=await SupabaseService.client.from('members').select('id').eq('auth_user_id',SupabaseService.client.auth.currentUser!.id).single();await SupabaseService.client.from('attendance').upsert({'meeting_id':meeting['id'],'member_id':m['id'],'present':present},onConflict:'meeting_id,member_id');if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Mahudhurio yamehifadhiwa.')));}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(err(e))));}}@override Widget build(BuildContext c)=>RefreshIndicator(onRefresh:load,child:ListView(padding:const EdgeInsets.all(16),children:[const Text('MAHUDHURIO',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),const SizedBox(height:6),const Text('Chagua kama ulihudhuria mkutano.'),const SizedBox(height:10),if(loading)const Center(child:CircularProgressIndicator()),if(!loading&&meetings.isEmpty)const Card(child:Padding(padding:EdgeInsets.all(18),child:Text('Hakuna mikutano iliyowekwa bado.'))),...meetings.map((m)=>Card(child:ListTile(title:Text(m['title']??''),subtitle:Text('${m['meeting_date']} • ${m['venue']??''}'),trailing:Wrap(children:[IconButton(onPressed:()=>mark(m,true),icon:const Icon(Icons.check_circle)),IconButton(onPressed:()=>mark(m,false),icon:const Icon(Icons.cancel_outlined))]))))]));}

class ProfilePage extends StatelessWidget{final Map<String,dynamic> row;final VoidCallback onLogout;const ProfilePage({super.key,required this.row,required this.onLogout});@override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[const Brand(),const SizedBox(height:20),Card(child:Column(children:[ListTile(title:const Text('Jina kamili'),subtitle:Text(row['full_name']??'')),ListTile(title:const Text('Namba ya mwanachama'),subtitle:Text(row['member_no']??'')),ListTile(title:const Text('Nafasi'),subtitle:Text(row['role']??'')),ListTile(title:const Text('Hali'),subtitle:Text(row['status']??''))])),const SizedBox(height:15),OutlinedButton.icon(onPressed:onLogout,icon:const Icon(Icons.logout),label:const Text('TOKA'))]);}


class AuditLogPage extends StatefulWidget{const AuditLogPage({super.key});@override State<AuditLogPage> createState()=>_AuditLogPageState();}
class _AuditLogPageState extends State<AuditLogPage>{List<Map<String,dynamic>> rows=[];bool loading=true;Future<void> load()async{try{final r=await AuditService.latest();if(mounted)setState(()=>rows=r);}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(err(e))));}finally{if(mounted)setState(()=>loading=false);}}@override void initState(){super.initState();load();}@override Widget build(BuildContext c)=>RefreshIndicator(onRefresh:load,child:ListView(padding:const EdgeInsets.all(16),children:[const Text('AUDIT LOG',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),const SizedBox(height:8),const Text('Kumbukumbu za vitendo muhimu vya mfumo.'),const SizedBox(height:12),if(loading)const Center(child:CircularProgressIndicator()),if(!loading&&rows.isEmpty)const Card(child:Padding(padding:EdgeInsets.all(16),child:Text('Hakuna audit log bado.'))),...rows.map((x)=>Card(child:ListTile(leading:const Icon(Icons.security),title:Text(x['action']??''),subtitle:Text('${x['entity_type']??''} • ${x['created_at']??''}'),isThreeLine:true,trailing:const Icon(Icons.chevron_right))))]));}


class SettingsPage extends StatefulWidget{final Map<String,dynamic> row;final bool isAdmin;const SettingsPage({super.key,required this.row,required this.isAdmin});@override State<SettingsPage> createState()=>_SettingsState();}
class _SettingsState extends State<SettingsPage>{
  bool notifications=true, compact=false;
  Future<void> changePassword()async{
    final c=TextEditingController();
    final ok=await showDialog<bool>(context:context,builder:(d)=>AlertDialog(title:const Text('Badili password'),content:TextField(controller:c,obscureText:true,decoration:const InputDecoration(labelText:'Password mpya',border:OutlineInputBorder())),actions:[TextButton(onPressed:()=>Navigator.pop(d,false),child:const Text('Ghairi')),FilledButton(onPressed:()=>Navigator.pop(d,true),child:const Text('Hifadhi'))]));
    if(ok==true&&c.text.length>=6){try{await SupabaseService.client.auth.updateUser(UserAttributes(password:c.text));if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Password imebadilishwa.')));}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(err(e))));}}else if(ok==true&&mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Password iwe na angalau herufi 6.')));}
  }
  @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[const Text('MIPANGILIO',style:TextStyle(fontSize:22,fontWeight:FontWeight.w900)),const SizedBox(height:12),Card(child:Column(children:[ListTile(leading:const Icon(Icons.groups),title:const Text('Chama'),subtitle:const Text('SURUMALA CLASSMENT 2017')),ListTile(leading:const Icon(Icons.payments),title:const Text('Mchango wa mwezi'),subtitle:const Text('TSH 5,000 • M-Pesa')),ListTile(leading:const Icon(Icons.person),title:const Text('Nafasi yako'),subtitle:Text(widget.row['role']??'MEMBER'))])),const SizedBox(height:10),Card(child:Column(children:[SwitchListTile(value:notifications,onChanged:(v)=>setState(()=>notifications=v),title:const Text('Notifications'),subtitle:const Text('Pokea taarifa za chama')),SwitchListTile(value:compact,onChanged:(v)=>setState(()=>compact=v),title:const Text('Muonekano mfupi'),subtitle:const Text('Punguza nafasi kati ya vitu'))])),const SizedBox(height:10),Card(child:Column(children:[ListTile(leading:const Icon(Icons.lock_reset),title:const Text('Badili password'),onTap:changePassword),if(isAdmin)ListTile(leading:const Icon(Icons.admin_panel_settings),title:const Text('Admin Panel'),subtitle:const Text('Simamia wanachama, malipo na ripoti'),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const AdminPage()))) ])),const SizedBox(height:10),const Card(child:Padding(padding:EdgeInsets.all(16),child:Text('Usalama: service-role key ya Supabase haipaswi kuwekwa ndani ya app.')))]);
}

class AdminPage extends StatefulWidget { const AdminPage({super.key}); @override State<AdminPage> createState()=>_AdminState(); }
class _AdminState extends State<AdminPage>{
  bool loading=true; String? error; int members=0,pendingMembers=0,paid=0,pendingPayments=0,present=0,absent=0,meetings=0; double total=0,expenses=0;
  List<Map<String,dynamic>> payments=[]; List<Map<String,dynamic>> pending=[];
  @override void initState(){super.initState();load();}
  Future<void> load() async { if(mounted)setState(()=>loading=true); try{
    final ms=List<Map<String,dynamic>>.from(await SupabaseService.client.from('members').select('id,member_no,full_name,role,status,created_at').order('created_at',ascending:false));
    members=ms.where((x)=>x['status']=='APPROVED').length; pendingMembers=ms.where((x)=>x['status']=='PENDING').length; pending=ms.where((x)=>x['status']=='PENDING').take(8).toList();
    final cs=List<Map<String,dynamic>>.from(await SupabaseService.client.from('contributions').select('id,member_id,amount,status,contribution_month,payment_method,created_at').order('created_at',ascending:false).limit(100));
    payments=cs.take(10).toList(); paid=cs.where((x)=>x['status']=='PAID').length; pendingPayments=cs.where((x)=>x['status']=='PENDING').length; total=cs.where((x)=>x['status']=='PAID').fold<double>(0,(v,x)=>v+((x['amount'] as num?)?.toDouble()??0));
    try { final ms2=await SupabaseService.client.from('meetings').select('id'); meetings=List.from(ms2).length; final at=List<Map<String,dynamic>>.from(await SupabaseService.client.from('attendance').select('present')); present=at.where((x)=>x['present']==true).length; absent=at.where((x)=>x['present']==false).length; } catch(_){ }
    try { final ex=await SupabaseService.client.from('expenses').select('amount'); final es=List<Map<String,dynamic>>.from(ex); expenses=es.fold<double>(0,(v,x)=>v+((x['amount'] as num?)?.toDouble()??0)); } catch(_){ }
  }catch(e){error=err(e);}finally{if(mounted)setState(()=>loading=false);}}
  Future<void> approve(String id,bool yes) async {try{await SupabaseService.client.from('members').update({'status':yes?'APPROVED':'REJECTED'}).eq('id',id);await load();}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(err(e))));}}
  @override Widget build(BuildContext c)=>RefreshIndicator(onRefresh:load,child:ListView(padding:const EdgeInsets.all(16),children:[
    Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[const Text('ADMIN DASHBOARD',style:TextStyle(fontSize:22,fontWeight:FontWeight.w900)),IconButton(onPressed:load,icon:const Icon(Icons.refresh))]),
    const Text('SURUMALA CLASSMENT 2017 • Muhtasari wa mfumo',style:TextStyle(color:Colors.black54)),const SizedBox(height:14),
    if(loading)const LinearProgressIndicator(),if(error!=null)Text(error!),
    Wrap(spacing:8,runSpacing:8,children:[_stat('Wanachama',members.toString(),Icons.groups),_stat('Pending',pendingMembers.toString(),Icons.pending_actions),_stat('Paid',paid.toString(),Icons.check_circle),_stat('Mikutano',meetings.toString(),Icons.event),_stat('Mahudhurio','+$present / -$absent',Icons.fact_check),_stat('Mapato','TSH ${total.toStringAsFixed(0)}',Icons.account_balance),_stat('Gharama','TSH ${expenses.toStringAsFixed(0)}',Icons.receipt_long),_stat('Salio','TSH ${(total-expenses).toStringAsFixed(0)}',Icons.savings)]),
    const SizedBox(height:20),_section('MAOMBI YA USAJILI'),
    if(!loading&&pending.isEmpty)const Card(child:Padding(padding:EdgeInsets.all(16),child:Text('Hakuna maombi mapya.'))),
    ...pending.map((m)=>Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.person)),title:Text(m['full_name']??''),subtitle:Text('${m['member_no']??''} • ${m['role']??'MEMBER'}'),trailing:Wrap(children:[IconButton(onPressed:()=>approve(m['id'].toString(),true),icon:const Icon(Icons.check_circle)),IconButton(onPressed:()=>approve(m['id'].toString(),false),icon:const Icon(Icons.cancel))])))),
    const SizedBox(height:12),_section('MALIPO YA KARIBUNI'),
    if(!loading&&payments.isEmpty)const Card(child:Padding(padding:EdgeInsets.all(16),child:Text('Hakuna malipo bado.'))),
    ...payments.map((x)=>Card(child:ListTile(leading:Icon(x['status']=='PAID'?Icons.check_circle:Icons.hourglass_top,color:x['status']=='PAID'?green:gold),title:Text('TSH ${x['amount']}'),subtitle:Text('${x['contribution_month']} • ${x['payment_method']}'),trailing:Text(x['status'])))),
    const SizedBox(height:12),_section('TAARIFA YA FEDHA'),
    Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Mapato yaliyothibitishwa: TSH ${total.toStringAsFixed(0)}',style:const TextStyle(fontWeight:FontWeight.bold)),Text('Gharama zilizorekodiwa: TSH ${expenses.toStringAsFixed(0)}'),const Divider(),Text('Salio la makadirio: TSH ${(total-expenses).toStringAsFixed(0)}',style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900))]))),
    const SizedBox(height:12),const Card(child:Padding(padding:EdgeInsets.all(16),child:Text('Kumbuka: PAID pekee ndiyo huhesabiwa kama mapato. Hakuna module ya mikopo.')))
  ]));
  Widget _section(String s)=>Padding(padding:const EdgeInsets.only(bottom:8),child:Text(s,style:const TextStyle(fontWeight:FontWeight.w900,letterSpacing:.5)));
  Widget _stat(String t,String v,IconData i)=>SizedBox(width:170,child:Card(child:ListTile(dense:true,leading:Icon(i),title:Text(t,style:const TextStyle(fontSize:12)),subtitle:Text(v,style:const TextStyle(fontWeight:FontWeight.w900,fontSize:15)))));
}

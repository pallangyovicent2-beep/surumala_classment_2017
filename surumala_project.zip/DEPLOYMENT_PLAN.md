# SURUMALA CLASSMENT 2017 — V21 Deployment Plan

V21 is the production-deployment preparation step after the V20 Release Candidate.

## Required external setup
1. Create a Supabase project.
2. Enable phone/password authentication.
3. Run the database schema and RLS policies from the project source.
4. Configure Storage for member profile photos.
5. Create the first administrator through a controlled database/admin procedure.
6. Configure the chosen Tanzania M-Pesa provider and its server-side credentials.
7. Deploy the payment callback/webhook endpoint.
8. Test payments in sandbox before production.
9. Build Android, iOS and Web from the actual Flutter source in a Flutter-capable environment.
10. Perform end-to-end acceptance testing before release.

## Security rules
- Never put an M-Pesa secret, service-role key, or other privileged credential in the mobile/web client.
- Use HTTPS for production endpoints.
- Treat payment callbacks as untrusted input until signature/reference/status checks pass.
- Only server-side code may mark a contribution as PAID.
- Keep audit logs for administrative actions.

## Release acceptance
- Registration creates PENDING member.
- Admin approval changes member to APPROVED.
- Only APPROVED members can use protected member features.
- Monthly contribution is exactly TSH 5,000.
- No loan feature is present.
- Successful M-Pesa payment produces a verifiable transaction record and receipt.
- Failed/cancelled payments do not become PAID.
- Admin reports reconcile with confirmed payments.

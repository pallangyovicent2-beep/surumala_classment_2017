# SURUMALA CLASSMENT 2017 — V21

V21 is the production-deployment preparation package.

This package does **not** claim that the app has already been published to Google Play, Apple App Store, or a live web host. Those releases require the external accounts, Supabase configuration, M-Pesa provider credentials, and a Flutter-capable build environment.

See:
- `DEPLOYMENT_PLAN.md`
- `PRODUCTION_CHECKLIST.md`
- `V20_FINAL_RELEASE.md`

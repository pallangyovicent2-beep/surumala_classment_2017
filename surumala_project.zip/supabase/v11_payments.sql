-- SURUMALA CLASSMENT 2017 V11 — payment attempt ledger
create table if not exists public.payment_attempts (
  id uuid primary key default gen_random_uuid(),
  contribution_id uuid not null references public.contributions(id) on delete cascade,
  member_id uuid not null references public.members(id) on delete cascade,
  phone text not null,
  amount numeric(12,2) not null check(amount=5000),
  provider text not null default 'MPESA',
  provider_request_id text,
  provider_checkout_id text unique,
  status text not null default 'INITIATED' check(status in ('INITIATED','PENDING','PAID','FAILED','CANCELLED')),
  provider_message text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.payment_attempts enable row level security;

drop policy if exists "member_reads_own_payment_attempts" on public.payment_attempts;
create policy "member_reads_own_payment_attempts" on public.payment_attempts
for select to authenticated using (
  member_id in (select id from public.members where auth_user_id=auth.uid())
  or public.is_admin()
);

drop policy if exists "member_creates_own_payment_attempt" on public.payment_attempts;
create policy "member_creates_own_payment_attempt" on public.payment_attempts
for insert to authenticated with check (
  member_id in (select id from public.members where auth_user_id=auth.uid() and status='APPROVED')
  and amount=5000
);

-- Client never marks a payment PAID. The server/callback owns settlement.
drop policy if exists "admin_updates_payment_attempts" on public.payment_attempts;
create policy "admin_updates_payment_attempts" on public.payment_attempts
for update to authenticated using(public.is_admin()) with check(public.is_admin());

create or replace function public.touch_payment_attempt_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at=now(); return new; end; $$;

drop trigger if exists payment_attempts_touch_updated_at on public.payment_attempts;
create trigger payment_attempts_touch_updated_at before update on public.payment_attempts
for each row execute function public.touch_payment_attempt_updated_at();

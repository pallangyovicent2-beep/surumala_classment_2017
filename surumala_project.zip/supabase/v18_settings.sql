-- SURUMALA CLASSMENT 2017 V18 - Settings & admin management helpers
-- Run after the previous SQL migrations.

create table if not exists public.app_settings (
  id bigint generated always as identity primary key,
  setting_key text unique not null,
  setting_value text not null,
  updated_at timestamptz not null default now(),
  updated_by uuid references auth.users(id)
);

alter table public.app_settings enable row level security;

drop policy if exists "approved members read settings" on public.app_settings;
create policy "approved members read settings" on public.app_settings for select using (exists (select 1 from public.members m where m.auth_user_id=auth.uid() and m.status='APPROVED'));

drop policy if exists "admins manage settings" on public.app_settings;
create policy "admins manage settings" on public.app_settings for all using (exists (select 1 from public.members m where m.auth_user_id=auth.uid() and m.status='APPROVED' and m.role='ADMIN')) with check (exists (select 1 from public.members m where m.auth_user_id=auth.uid() and m.status='APPROVED' and m.role='ADMIN'));

insert into public.app_settings(setting_key,setting_value) values
 ('group_name','SURUMALA CLASSMENT 2017'),
 ('monthly_contribution','5000'),
 ('payment_method','MPESA')
on conflict(setting_key) do nothing;

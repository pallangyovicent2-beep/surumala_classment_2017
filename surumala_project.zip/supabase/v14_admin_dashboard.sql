-- SURUMALA CLASSMENT 2017 — V14 Admin dashboard support
-- Run after schema.sql and V11/V12/V13 SQL files.
-- Adds useful indexes for dashboard/report queries. No service-role key is used by the app.

create index if not exists idx_members_status_created_at on public.members(status, created_at desc);
create index if not exists idx_contributions_status_created_at on public.contributions(status, created_at desc);
create index if not exists idx_contributions_month on public.contributions(contribution_month);
create index if not exists idx_attendance_present on public.attendance(present);
create index if not exists idx_expenses_created_at on public.expenses(created_at desc);

-- Optional report view for admins. RLS on base tables still protects direct access.
create or replace view public.admin_financial_summary as
select
  coalesce((select sum(amount) from public.contributions where status='PAID'),0) as total_paid,
  coalesce((select count(*) from public.contributions where status='PAID'),0) as paid_count,
  coalesce((select count(*) from public.contributions where status='PENDING'),0) as pending_payment_count,
  coalesce((select sum(amount) from public.expenses),0) as total_expenses,
  coalesce((select count(*) from public.members where status='APPROVED'),0) as approved_members,
  coalesce((select count(*) from public.members where status='PENDING'),0) as pending_members;

-- The view is intended for authenticated admin reporting. If your project uses
-- stricter view security, keep using the dashboard's base-table queries instead.

-- SURUMALA CLASSMENT 2017 V12
-- Admin reporting helpers. Run AFTER schema.sql + V11 payment SQL.

create or replace view public.admin_financial_summary as
select
  count(*) filter (where status = 'PAID') as paid_count,
  count(*) filter (where status = 'PENDING') as pending_count,
  count(*) filter (where status = 'FAILED') as failed_count,
  coalesce(sum(amount) filter (where status = 'PAID'),0) as paid_total
from public.contributions;

alter table public.members add column if not exists approved_at timestamptz;
alter table public.members add column if not exists approved_by uuid references auth.users(id);

create or replace function public.mark_member_approval_metadata()
returns trigger language plpgsql security definer as $$
begin
  if new.status = 'APPROVED' and old.status is distinct from 'APPROVED' then
    new.approved_at = coalesce(new.approved_at, now());
    new.approved_by = auth.uid();
  end if;
  return new;
end;
$$;

drop trigger if exists trg_member_approval_metadata on public.members;
create trigger trg_member_approval_metadata before update on public.members
for each row execute function public.mark_member_approval_metadata();

-- Admins can read the financial summary view through the underlying RLS-safe tables.
-- Do not expose service-role keys in the Flutter app.

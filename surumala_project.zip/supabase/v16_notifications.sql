-- V16: Notifications + announcement delivery foundation
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  member_id uuid not null references public.members(id) on delete cascade,
  title text not null,
  body text not null,
  type text not null default 'GENERAL',
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create index if not exists notifications_member_created_idx on public.notifications(member_id, created_at desc);
alter table public.notifications enable row level security;

create policy "members read own notifications" on public.notifications
  for select using (member_id = auth.uid());
create policy "members update own notifications" on public.notifications
  for update using (member_id = auth.uid()) with check (member_id = auth.uid());

create or replace function public.notify_member(p_member uuid, p_title text, p_body text, p_type text default 'GENERAL')
returns void language sql security definer set search_path = public as $$
  insert into public.notifications(member_id,title,body,type) values (p_member,p_title,p_body,p_type);
$$;

-- Trigger: new member registration gets a welcome/pending notification.
create or replace function public.on_member_created_notification()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.notifications(member_id,title,body,type)
  values (new.id,'Usajili umepokelewa','Usajili wako wa SURUMALA CLASSMENT 2017 umepokelewa. Subiri Admin akuidhinishe.','REGISTRATION');
  return new;
end;
$$;

drop trigger if exists trg_member_notification on public.members;
create trigger trg_member_notification after insert on public.members
for each row execute function public.on_member_created_notification();

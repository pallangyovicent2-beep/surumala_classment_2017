-- Run AFTER schema.sql in your Supabase SQL editor.
-- These policies are a starting point; review them with your actual admin-role strategy.

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public
as $$
  select exists (
    select 1 from public.members m
    where m.auth_user_id = auth.uid()
      and m.role in ('ADMIN','CHAIRPERSON','SECRETARY','TREASURER')
      and m.status = 'APPROVED'
  );
$$;

create policy "approved members can read approved member directory"
on public.members for select to authenticated
using (status = 'APPROVED' or auth_user_id = auth.uid());

create policy "users can create their own pending member record"
on public.members for insert to authenticated
with check (auth_user_id = auth.uid() and status = 'PENDING' and role = 'MEMBER');

create policy "admins can update members"
on public.members for update to authenticated
using (public.is_admin()) with check (public.is_admin());

create policy "members read own contributions"
on public.contributions for select to authenticated
using (exists (select 1 from public.members m where m.id = member_id and m.auth_user_id = auth.uid()) or public.is_admin());

create policy "admins manage contributions"
on public.contributions for all to authenticated
using (public.is_admin()) with check (public.is_admin());

create policy "approved users read announcements"
on public.announcements for select to authenticated
using (exists (select 1 from public.members m where m.auth_user_id = auth.uid() and m.status = 'APPROVED'));

create policy "admins manage announcements"
on public.announcements for all to authenticated
using (public.is_admin()) with check (public.is_admin());

create policy "approved users read meetings"
on public.meetings for select to authenticated
using (exists (select 1 from public.members m where m.auth_user_id = auth.uid() and m.status = 'APPROVED'));

create policy "admins manage meetings"
on public.meetings for all to authenticated
using (public.is_admin()) with check (public.is_admin());

create policy "admins manage expenses"
on public.expenses for all to authenticated
using (public.is_admin()) with check (public.is_admin());

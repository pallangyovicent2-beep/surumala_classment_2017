-- Baada ya kujisajili na ku-approve mwanachama wa kwanza, Admin anaweza kupewa role hii.
-- Badilisha PHONE kuwa namba ya mwanachama huyo.
update public.members set role='ADMIN', status='APPROVED', approved_at=now() where phone='+255XXXXXXXXX';

// V11 server-side payment boundary.
// IMPORTANT: Provider credentials belong in Supabase Edge Function secrets,
// never in the Flutter app. Configure the exact Tanzania M-Pesa provider/API
// contract before enabling live collection.
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const supabase = createClient(supabaseUrl, serviceKey);

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } });
}

function normalizeTzPhone(input: string): string {
  const digits = input.replace(/[^0-9]/g, '');
  if (digits.startsWith('255') && digits.length === 12) return digits;
  if (digits.startsWith('0') && digits.length === 10) return '255' + digits.slice(1);
  throw new Error('Namba ya simu ya Tanzania si sahihi. Tumia 07XXXXXXXX au 2557XXXXXXXX.');
}

Deno.serve(async (req) => {
  if (req.method !== 'POST') return json({ error: 'POST only' }, 405);
  const authHeader = req.headers.get('Authorization');
  if (!authHeader) return json({ error: 'Missing authorization' }, 401);

  const jwt = authHeader.replace('Bearer ', '');
  const userClient = createClient(supabaseUrl, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: `Bearer ${jwt}` } } });
  const { data: { user } } = await userClient.auth.getUser();
  if (!user) return json({ error: 'Unauthorized' }, 401);

  try {
    const body = await req.json();
    const contributionId = String(body.contribution_id ?? '');
    const phone = normalizeTzPhone(String(body.phone ?? ''));
    if (!contributionId) return json({ error: 'contribution_id is required' }, 400);

    const { data: member } = await supabase.from('members').select('id,status,phone').eq('auth_user_id', user.id).single();
    if (!member || member.status !== 'APPROVED') return json({ error: 'Mwanachama hajaidhinishwa.' }, 403);

    const { data: contribution } = await supabase.from('contributions').select('id,member_id,amount,status').eq('id', contributionId).single();
    if (!contribution || contribution.member_id !== member.id || Number(contribution.amount) !== 5000) return json({ error: 'Mchango haujapatikana.' }, 400);
    if (contribution.status === 'PAID') return json({ error: 'Mchango huu tayari umelipwa.' }, 409);

    const { data: attempt, error: attemptError } = await supabase.from('payment_attempts').insert({
      contribution_id: contribution.id, member_id: member.id, phone, amount: 5000, provider: 'MPESA', status: 'INITIATED'
    }).select().single();
    if (attemptError) throw attemptError;

    // Provider adapter: intentionally refuses to fake a real payment when live
    // provider credentials/endpoints have not been configured.
    const providerUrl = Deno.env.get('MPESA_STK_URL');
    const consumerKey = Deno.env.get('MPESA_CONSUMER_KEY');
    const consumerSecret = Deno.env.get('MPESA_CONSUMER_SECRET');
    const shortcode = Deno.env.get('MPESA_SHORTCODE');
    const passkey = Deno.env.get('MPESA_PASSKEY');

    if (!providerUrl || !consumerKey || !consumerSecret || !shortcode || !passkey) {
      await supabase.from('payment_attempts').update({ status: 'FAILED', provider_message: 'M-Pesa provider secrets hazijawekwa.' }).eq('id', attempt.id);
      return json({ error: 'M-Pesa bado haijawekewa credentials za live/sandbox.', payment_attempt_id: attempt.id }, 503);
    }

    // The exact request/auth contract varies by M-Pesa market/provider.
    // Implement the provider-specific request here after credentials are issued.
    await supabase.from('payment_attempts').update({ status: 'FAILED', provider_message: 'Provider adapter iko tayari; endpoint/payload ya Tanzania inahitaji kuthibitishwa na mtoa huduma.' }).eq('id', attempt.id);
    return json({ error: 'Provider adapter haijawezeshwa bado.', payment_attempt_id: attempt.id }, 501);
  } catch (e) {
    return json({ error: e instanceof Error ? e.message : 'Payment error' }, 500);
  }
});

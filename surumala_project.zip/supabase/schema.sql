-- SURUMALA CLASSMENT 2017 — V9 production-ready foundation
create extension if not exists pgcrypto;

create sequence if not exists public.member_no_seq start 1;
create table if not exists public.members (
 id uuid primary key default gen_random_uuid(), auth_user_id uuid unique references auth.users(id) on delete cascade,
 member_no text unique not null, full_name text not null, phone text not null unique, location text,
 role text not null default 'MEMBER' check(role in ('ADMIN','CHAIRPERSON','SECRETARY','TREASURER','MEMBER')),
 status text not null default 'PENDING' check(status in ('PENDING','APPROVED','REJECTED','SUSPENDED')),
 created_at timestamptz not null default now(), approved_at timestamptz, approved_by uuid references auth.users(id)
);

create or replace function public.next_member_no() returns text language plpgsql as $$
declare n bigint; begin n:=nextval('public.member_no_seq'); return 'SC2017-'||lpad(n::text,4,'0'); end; $$;

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into public.members(auth_user_id,member_no,full_name,phone,location) values(new.id,public.next_member_no(),coalesce(new.raw_user_meta_data->>'full_name','MEMBER'),new.phone,new.raw_user_meta_data->>'location'); return new; end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

create table if not exists public.contributions (id uuid primary key default gen_random_uuid(),member_id uuid not null references public.members(id) on delete cascade,amount numeric(12,2) not null check(amount=5000),contribution_month date not null,payment_method text not null default 'MPESA',transaction_reference text unique,status text not null default 'PENDING' check(status in('PENDING','PAID','FAILED','REVERSED')),paid_at timestamptz,created_at timestamptz not null default now(),unique(member_id,contribution_month));
create table if not exists public.announcements (id uuid primary key default gen_random_uuid(),title text not null,body text not null,created_by uuid references auth.users(id),created_at timestamptz not null default now());
create table if not exists public.meetings (id uuid primary key default gen_random_uuid(),title text not null,meeting_date timestamptz not null,venue text,notes text,created_by uuid references auth.users(id),created_at timestamptz not null default now());
create table if not exists public.expenses (id uuid primary key default gen_random_uuid(),amount numeric(12,2) not null check(amount>0),description text not null,spent_at timestamptz not null default now(),created_by uuid references auth.users(id));

alter table public.members enable row level security; alter table public.contributions enable row level security; alter table public.announcements enable row level security; alter table public.meetings enable row level security; alter table public.expenses enable row level security;
create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from public.members where auth_user_id=auth.uid() and role='ADMIN' and status='APPROVED'); $$;

drop policy if exists "member_self_or_approved_directory" on public.members;
create policy "member_self_or_approved_directory" on public.members for select to authenticated using(auth_user_id=auth.uid() or status='APPROVED');
drop policy if exists "admin_updates_members" on public.members;
create policy "admin_updates_members" on public.members for update to authenticated using(public.is_admin()) with check(public.is_admin());
create policy if not exists "own_contributions" on public.contributions for select to authenticated using(exists(select 1 from public.members m where m.id=member_id and m.auth_user_id=auth.uid()) or public.is_admin());
create policy if not exists "admin_contributions" on public.contributions for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy if not exists "approved_announcements" on public.announcements for select to authenticated using(exists(select 1 from public.members m where m.auth_user_id=auth.uid() and m.status='APPROVED'));
create policy if not exists "admin_announcements" on public.announcements for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy if not exists "approved_meetings" on public.meetings for select to authenticated using(exists(select 1 from public.members m where m.auth_user_id=auth.uid() and m.status='APPROVED'));
create policy if not exists "admin_meetings" on public.meetings for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy if not exists "admin_expenses" on public.expenses for all to authenticated using(public.is_admin()) with check(public.is_admin());

-- V10 contribution security: an approved member may create only their own pending TSH 5,000 record.
drop policy if exists "member_creates_own_contribution" on public.contributions;
create policy "member_creates_own_contribution" on public.contributions
for insert to authenticated
with check (
  status='PENDING' and amount=5000 and payment_method='MPESA'
  and exists(select 1 from public.members m where m.id=member_id and m.auth_user_id=auth.uid() and m.status='APPROVED')
);

-- Admin approval helper: sets approval metadata when a member becomes APPROVED.
create or replace function public.set_approval_metadata() returns trigger language plpgsql as $$
begin
  if new.status='APPROVED' and (old.status is distinct from 'APPROVED') then
    new.approved_at=coalesce(new.approved_at,now());
    new.approved_by=coalesce(new.approved_by,auth.uid());
  end if;
  return new;
end; $$;
drop trigger if exists members_approval_metadata on public.members;
create trigger members_approval_metadata before update on public.members for each row execute function public.set_approval_metadata();

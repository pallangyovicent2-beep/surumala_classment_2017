-- V13: announcements + attendance
create table if not exists public.attendance (
 id uuid primary key default gen_random_uuid(),
 meeting_id uuid not null references public.meetings(id) on delete cascade,
 member_id uuid not null references public.members(id) on delete cascade,
 present boolean not null default false,
 marked_at timestamptz not null default now(),
 unique(meeting_id, member_id)
);
alter table public.attendance enable row level security;
create policy "attendance own read" on public.attendance for select using (member_id = (select id from public.members where auth_user_id=auth.uid()));
create policy "attendance admin all" on public.attendance for all using (public.is_admin()) with check (public.is_admin());

alter table public.announcements enable row level security;
create policy "announcements approved read" on public.announcements for select using (exists(select 1 from public.members m where m.auth_user_id=auth.uid() and m.status='APPROVED'));
create policy "announcements admin write" on public.announcements for all using (public.is_admin()) with check (public.is_admin());

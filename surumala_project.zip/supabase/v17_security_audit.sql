-- V17: Security hardening + audit log
create table if not exists public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references auth.users(id) on delete set null,
  action text not null,
  entity_type text not null,
  entity_id uuid,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists audit_logs_created_idx on public.audit_logs(created_at desc);
create index if not exists audit_logs_actor_idx on public.audit_logs(actor_id, created_at desc);
alter table public.audit_logs enable row level security;

drop policy if exists "admins read audit logs" on public.audit_logs;
create policy "admins read audit logs" on public.audit_logs for select using (public.is_admin());

create or replace function public.write_audit_log(p_action text,p_entity_type text,p_entity_id uuid,p_details jsonb default '{}'::jsonb)
returns void language plpgsql security definer set search_path=public as $$
begin
  insert into public.audit_logs(actor_id,action,entity_type,entity_id,details)
  values (auth.uid(),p_action,p_entity_type,p_entity_id,coalesce(p_details,'{}'::jsonb));
end; $$;

-- Log member status/role changes made through the database.
create or replace function public.audit_member_changes()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  if (old.status is distinct from new.status) then
    perform public.write_audit_log('MEMBER_STATUS_CHANGED','members',new.id,jsonb_build_object('from',old.status,'to',new.status));
  end if;
  if (old.role is distinct from new.role) then
    perform public.write_audit_log('MEMBER_ROLE_CHANGED','members',new.id,jsonb_build_object('from',old.role,'to',new.role));
  end if;
  return new;
end; $$;
drop trigger if exists trg_audit_member_changes on public.members;
create trigger trg_audit_member_changes after update of status, role on public.members
for each row execute function public.audit_member_changes();

-- Log contribution status changes (e.g. payment confirmation).
create or replace function public.audit_contribution_changes()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  if (old.status is distinct from new.status) then
    perform public.write_audit_log('CONTRIBUTION_STATUS_CHANGED','contributions',new.id,jsonb_build_object('from',old.status,'to',new.status,'amount',new.amount,'month',new.contribution_month));
  end if;
  return new;
end; $$;
drop trigger if exists trg_audit_contribution_changes on public.contributions;
create trigger trg_audit_contribution_changes after update of status on public.contributions
for each row execute function public.audit_contribution_changes();

-- Audit important attendance changes.
create or replace function public.audit_attendance_changes()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  if (TG_OP='INSERT') then
    perform public.write_audit_log('ATTENDANCE_RECORDED','attendance',new.id,jsonb_build_object('meeting_id',new.meeting_id,'member_id',new.member_id,'present',new.present));
  elsif (old.present is distinct from new.present) then
    perform public.write_audit_log('ATTENDANCE_CHANGED','attendance',new.id,jsonb_build_object('from',old.present,'to',new.present));
  end if;
  return new;
end; $$;
drop trigger if exists trg_audit_attendance_changes on public.attendance;
create trigger trg_audit_attendance_changes after insert or update of present on public.attendance
for each row execute function public.audit_attendance_changes();

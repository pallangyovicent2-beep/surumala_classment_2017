# SURUMALA CLASSMENT 2017 — V19 QA / Hardening Checklist

V19 is the pre-release quality and hardening baseline. The Flutter SDK is not bundled with this ZIP, so final device/browser compilation must be performed in a Flutter-capable environment.

## Automated/static checks completed
- Project contains Flutter entrypoint and `pubspec.yaml`.
- Supabase schema and feature SQL files are present.
- Monthly contribution is constrained to **TSH 5,000** in the database schema.
- Payment method defaults to **MPESA**.
- No loan module is present in the project SQL/UI references.
- Supabase service-role key is referenced only by the server-side Edge Function environment, not by Flutter client configuration.
- Client configuration uses `SUPABASE_URL` and `SUPABASE_ANON_KEY` via `--dart-define`.

## Manual test plan before production
1. Register a new member with a Tanzanian phone number.
2. Confirm the member is created as `PENDING`.
3. Confirm a non-approved member cannot enter the dashboard.
4. Promote one trusted account to `ADMIN` using the secure SQL bootstrap procedure.
5. Approve a pending member from Admin.
6. Log in as the approved member.
7. Confirm the member can view/edit their profile only.
8. Confirm the approved member directory is visible according to RLS.
9. Start a TSH 5,000 M-Pesa payment and verify it remains untrusted until the server callback confirms it.
10. Confirm only `PAID` contributions are counted in financial totals.
11. Create/read announcements and verify notification ownership.
12. Record attendance and verify the member cannot edit another member's attendance.
13. Verify Admin-only audit logs.
14. Verify logout removes the active session.
15. Test on Android, iPhone/Safari, and Web/Chrome at release time.

## Release blockers
- Do not ship with a Supabase service-role key inside the Flutter app.
- Do not mark a payment `PAID` from the client app.
- Configure the real M-Pesa provider credentials only in server/Edge Function secrets.
- Apply all required SQL migrations to the intended Supabase project.
- Verify RLS policies in the actual project before inviting real members.
